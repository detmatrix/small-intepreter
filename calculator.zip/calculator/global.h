#include <stdio.h>
#include <ctype.h>
#define BSIZE 10 /*size of buffer*/
#define NONE -1

#define NUM 256    /*identifier for number, functions pow() and sin(), endmark*/
#define POW 257
#define SIN 258
#define DONE 259

double tokenval;   /*attribute to token*/
int lineno;       /* line number*/

typedef struct {
	char *lexptr;
	int token;
}entry;
entry symtable[];