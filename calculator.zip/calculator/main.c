#include "global.h"
#include <stdlib.h>

double result;
extern void parse();
int main()
{
	printf("end your expression with ';', type EOF to quit\n");
	result = 0;
	parse();          
	return 0;
}